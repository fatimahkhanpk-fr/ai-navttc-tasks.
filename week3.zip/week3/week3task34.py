# Week 3 - Task 34: NumPy - array reshaping
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])

# 1D -> 2D
print("reshape(4, 3):\n", arr.reshape(4, 3))
print("reshape(2, 6):\n", arr.reshape(2, 6))

# 1D -> 3D
print("reshape(2, 3, 2):\n", arr.reshape(2, 3, 2))

# Unknown dimension: use -1 and NumPy calculates it
print("reshape(2, 2, -1):\n", arr.reshape(2, 2, -1))
print("reshape(-1, 4) shape:", arr.reshape(-1, 4).shape)

# Flattening: n-D -> 1D
two_d = np.array([[1, 2, 3], [4, 5, 6]])
print("reshape(-1):", two_d.reshape(-1))
print("flatten()  :", two_d.flatten())
print("ravel()    :", two_d.ravel())

# Invalid reshape
try:
    arr.reshape(5, 3)
except ValueError as e:
    print("ValueError:", e)

# Other shape tools
print("transpose:\n", two_d.T)
print("expand_dims shape:", np.expand_dims(arr, axis=0).shape)
print("squeeze shape:", np.squeeze(np.expand_dims(arr, axis=0)).shape)
