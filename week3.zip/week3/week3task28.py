# Week 3 - Task 28: NumPy - creating arrays
import numpy as np

print("NumPy version:", np.__version__)

# From Python lists / tuples
a = np.array([1, 2, 3, 4, 5])
b = np.array((10, 20, 30))
print("1D:", a, "| type:", type(a))

# Dimensions
d0 = np.array(42)
d1 = np.array([1, 2, 3])
d2 = np.array([[1, 2, 3], [4, 5, 6]])
d3 = np.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])
for name, arr in [("0-D", d0), ("1-D", d1), ("2-D", d2), ("3-D", d3)]:
    print(name, "ndim =", arr.ndim)

# Higher dimensional arrays
print("5-D ndim:", np.array([1, 2, 3, 4], ndmin=5).ndim)

# Built-in creation methods
print("zeros:\n", np.zeros((2, 3)))
print("ones:\n", np.ones((2, 2)))
print("full:\n", np.full((2, 2), 7))
print("eye:\n", np.eye(3))
print("arange:", np.arange(0, 10, 2))
print("linspace:", np.linspace(0, 1, 5))
print("empty shape:", np.empty((2, 2)).shape)

# From random
np.random.seed(0)
print("random floats:\n", np.random.rand(2, 3))
print("random ints:", np.random.randint(1, 100, size=5))
print("normal:", np.random.randn(3))
