# Week 3 - Task 40: NumPy - random numbers
import numpy as np
from numpy import random

np.random.seed(42)  # reproducible results

print("randint(100):", random.randint(100))
print("rand():", random.rand())
print("randint array:", random.randint(100, size=5))
print("randint 2D:\n", random.randint(100, size=(3, 5)))
print("rand 2D:\n", random.rand(2, 3).round(3))

# Choice from a given list
print("choice:", random.choice([3, 5, 7, 9]))
print("choice array:\n", random.choice([3, 5, 7, 9], size=(2, 3)))
print("choice with probabilities:",
      random.choice([3, 5, 7, 9], p=[0.1, 0.3, 0.6, 0.0], size=10))

# Shuffle and permutation
arr = np.array([1, 2, 3, 4, 5])
random.shuffle(arr)
print("shuffle:", arr)
print("permutation:", random.permutation(np.array([1, 2, 3, 4, 5])))

# Distributions
print("normal :", random.normal(loc=0, scale=1, size=5).round(3))
print("uniform:", random.uniform(0, 10, size=5).round(3))
print("binomial:", random.binomial(n=10, p=0.5, size=5))
print("poisson:", random.poisson(lam=2, size=5))

# New-style generator
rng = np.random.default_rng(7)
print("default_rng:", rng.integers(0, 10, size=5))
