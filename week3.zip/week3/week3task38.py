# Week 3 - Task 38: NumPy - searching arrays
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 4, 4])

# where: indexes of values that match
print("where == 4:", np.where(arr == 4))
print("where even:", np.where(arr % 2 == 0)[0])

# where with a condition and replacement values
print("replace >3 with 0:", np.where(arr > 3, 0, arr))

# searchsorted: binary search in a SORTED array
sorted_arr = np.array([6, 7, 8, 9])
print("\nsearchsorted(7)       :", np.searchsorted(sorted_arr, 7))
print("searchsorted(7, right):", np.searchsorted(sorted_arr, 7, side="right"))
print("multiple values       :", np.searchsorted(np.array([1, 3, 5, 7]), [2, 4, 6]))

# argmax / argmin
print("\nargmax:", arr.argmax(), "| argmin:", arr.argmin())

# Boolean checks
print("any > 4:", (arr > 4).any(), "| all > 0:", (arr > 0).all())
print("count of 4s:", np.count_nonzero(arr == 4))

# Membership
print("isin:", np.isin(arr, [1, 5]))
