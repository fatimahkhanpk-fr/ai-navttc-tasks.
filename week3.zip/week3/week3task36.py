# Week 3 - Task 36: NumPy - joining arrays
import numpy as np

a = np.array([1, 2, 3])
b = np.array([4, 5, 6])

# concatenate
print("concatenate:", np.concatenate((a, b)))

a2 = np.array([[1, 2], [3, 4]])
b2 = np.array([[5, 6], [7, 8]])
print("axis=0 (rows):\n", np.concatenate((a2, b2), axis=0))
print("axis=1 (columns):\n", np.concatenate((a2, b2), axis=1))

# stack: joins along a NEW axis
print("stack axis=0:\n", np.stack((a, b), axis=0))
print("stack axis=1:\n", np.stack((a, b), axis=1))

# hstack / vstack / dstack
print("hstack:", np.hstack((a, b)))
print("vstack:\n", np.vstack((a, b)))
print("dstack:\n", np.dstack((a, b)))

# append / insert / delete
print("append:", np.append(a, [7, 8]))
print("insert:", np.insert(a, 1, 99))
print("delete:", np.delete(a, 0))
