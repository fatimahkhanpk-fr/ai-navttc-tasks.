# Week 3 - Task 37: NumPy - splitting arrays
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6])

# array_split into 3 parts
parts = np.array_split(arr, 3)
print("array_split(3):", parts)
print("first part:", parts[0], "| second part:", parts[1])

# uneven split still works with array_split
print("array_split(4):", np.array_split(arr, 4))

# split requires an equal division
print("split(3):", np.split(arr, 3))
try:
    np.split(arr, 4)
except ValueError as e:
    print("split(4) error:", e)

# Split at given positions
print("split at [2, 4]:", np.split(arr, [2, 4]))

# 2D arrays
arr2 = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12]])
print("\nsplit rows into 3:")
for p in np.array_split(arr2, 3):
    print(p)
print("hsplit into 2 columns:")
for p in np.hsplit(arr2, 2):
    print(p.ravel())
print("vsplit into 2:")
for p in np.vsplit(arr2, 2):
    print(p.tolist())
