# Week 3 - Task 30: NumPy - slicing arrays
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print("arr[1:5]  =", arr[1:5])
print("arr[4:]   =", arr[4:])
print("arr[:4]   =", arr[:4])
print("arr[-3:-1]=", arr[-3:-1])
print("arr[1:5:2]=", arr[1:5:2])
print("arr[::2]  =", arr[::2])
print("arr[::-1] =", arr[::-1])

# 2D slicing
arr2 = np.array([[1, 2, 3, 4, 5],
                 [6, 7, 8, 9, 10],
                 [11, 12, 13, 14, 15]])
print("\narr2[1, 1:4]    =", arr2[1, 1:4])
print("arr2[0:2, 2]    =", arr2[0:2, 2])
print("arr2[0:2, 1:4]:\n", arr2[0:2, 1:4])
print("arr2[:, ::2]:\n", arr2[:, ::2])
print("First column:", arr2[:, 0], "| last row:", arr2[-1])

# Slices are views, not copies
view = arr[1:4]
view[0] = 99
print("\nModifying the slice changes the original:", arr)
