# Week 3 - Task 31: NumPy - data types
import numpy as np

# Default types
print("int array   :", np.array([1, 2, 3]).dtype)
print("float array :", np.array([1.5, 2.5]).dtype)
print("string array:", np.array(["apple", "banana"]).dtype)
print("bool array  :", np.array([True, False]).dtype)
print("mixed       :", np.array([1, 2.5, 3]).dtype)

# Data type codes: i, u, f, c, b, S, U
print("\nCodes: i (int), u (unsigned), f (float), c (complex), b (bool), S (bytes), U (unicode)")

# Define the type explicitly
print(np.array([1, 2, 3, 4], dtype="S").dtype)
print(np.array([1, 2, 3, 4], dtype="i4"), np.array([1, 2, 3, 4], dtype="i4").dtype)
print(np.array([1, 2, 3], dtype=np.float64).dtype)

# Convert type with astype
arr = np.array([1.1, 2.1, 3.1])
print("\nastype int  :", arr.astype("i"))
print("astype int  :", arr.astype(int))
print("astype bool :", np.array([1, 0, 2]).astype(bool))
print("astype str  :", np.array([1, 2, 3]).astype(str))

# A value that cannot be converted raises an error
try:
    np.array(["a", "b"], dtype="i")
except ValueError as e:
    print("\nValueError:", e)

# Memory used by different types
print("\nint8 size:", np.array([1], dtype=np.int8).itemsize, "byte(s)",
      "| int64 size:", np.array([1], dtype=np.int64).itemsize, "bytes")
