# Week 3 - Task 33: NumPy - array shape
import numpy as np

a1 = np.array([1, 2, 3, 4])
a2 = np.array([[1, 2, 3, 4], [5, 6, 7, 8]])
a3 = np.arange(24).reshape(2, 3, 4)

for name, arr in [("1-D", a1), ("2-D", a2), ("3-D", a3)]:
    print(f"{name}: shape={arr.shape}, ndim={arr.ndim}, size={arr.size}")

# A 5-dimensional array: the last number is the length of the innermost dimension
arr5 = np.array([1, 2, 3, 4], ndmin=5)
print("\n5-D array:", arr5)
print("shape:", arr5.shape)

# Other attributes
print("\ndtype:", a2.dtype, "| itemsize:", a2.itemsize, "| nbytes:", a2.nbytes)
print("len(a2):", len(a2), "(length of first dimension)")
print("Transpose shape:", a2.T.shape)
