# Week 3 - Task 39: NumPy - sorting arrays
import numpy as np

arr = np.array([3, 2, 0, 1])
print("sorted numbers:", np.sort(arr))
print("original unchanged:", arr)

print("sorted strings:", np.sort(np.array(["banana", "cherry", "apple"])))
print("sorted booleans:", np.sort(np.array([True, False, True])))

# Descending
print("descending:", np.sort(arr)[::-1])

# 2D: each row is sorted
arr2 = np.array([[3, 2, 4], [5, 0, 1]])
print("2D sort (rows):\n", np.sort(arr2))
print("2D sort (columns):\n", np.sort(arr2, axis=0))

# argsort: indexes that would sort the array
print("argsort:", np.argsort(arr))

# Sorting one array by another
names = np.array(["Ali", "Sara", "Ahmed"])
scores = np.array([80, 95, 70])
order = np.argsort(scores)[::-1]
print("names by score (high to low):", names[order])

# In-place sort
arr.sort()
print("in-place:", arr)
