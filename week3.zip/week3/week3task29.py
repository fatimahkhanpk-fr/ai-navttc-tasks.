# Week 3 - Task 29: NumPy - indexing arrays
import numpy as np

# 1D
arr = np.array([10, 20, 30, 40, 50])
print("arr[0] =", arr[0], "| arr[2] + arr[3] =", arr[2] + arr[3], "| arr[-1] =", arr[-1])

# 2D: arr[row, column]
arr2 = np.array([[1, 2, 3, 4, 5],
                 [6, 7, 8, 9, 10]])
print("2D arr2[0, 1] =", arr2[0, 1])
print("2D arr2[1, -1] =", arr2[1, -1])
print("Row 1:", arr2[1], "| Column 2:", arr2[:, 2])

# 3D: arr[block, row, column]
arr3 = np.array([[[1, 2, 3], [4, 5, 6]],
                 [[7, 8, 9], [10, 11, 12]]])
print("3D arr3[0, 1, 2] =", arr3[0, 1, 2])
print("3D arr3[1, 0, 0] =", arr3[1, 0, 0])

# Logical (boolean) selection
data = np.array([3, 8, 1, 9, 4, 7])
print("data > 4:", data > 4)
print("values > 4:", data[data > 4])
print("even values:", data[data % 2 == 0])

# Fancy indexing
print("fancy:", data[[0, 2, 4]])
