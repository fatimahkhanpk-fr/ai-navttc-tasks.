# Week 3 - Task 35: NumPy - array iteration
import numpy as np

# 1D
arr = np.array([1, 2, 3])
for x in arr:
    print(x)

# 2D: iterating gives rows
arr2 = np.array([[1, 2, 3], [4, 5, 6]])
print("\nRows:")
for row in arr2:
    print(row)

print("\nEvery element:")
for row in arr2:
    for x in row:
        print(x, end=" ")
print()

# 3D
arr3 = np.array([[[1, 2], [3, 4]], [[5, 6], [7, 8]]])
print("\n3D elements:")
for x in np.nditer(arr3):
    print(x, end=" ")
print()

# nditer with data type conversion
print("\nAs strings:")
for x in np.nditer(arr2, flags=["buffered"], op_dtypes=["S"]):
    print(x, end=" ")
print()

# Step while iterating
print("\nEvery other element of a 2D array:")
for x in np.nditer(arr2[:, ::2]):
    print(x, end=" ")
print()

# ndenumerate: index + value
print("\nndenumerate:")
for idx, x in np.ndenumerate(arr2):
    print(idx, x)
