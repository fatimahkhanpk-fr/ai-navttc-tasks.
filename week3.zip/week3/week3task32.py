# Week 3 - Task 32: NumPy - array copy vs view
import numpy as np

# COPY: owns its data, changes do NOT affect the original
arr = np.array([1, 2, 3, 4, 5])
x = arr.copy()
arr[0] = 42
print("Copy test")
print("  original:", arr)
print("  copy    :", x)

# VIEW: does not own data, changes DO affect the original
arr = np.array([1, 2, 3, 4, 5])
y = arr.view()
arr[0] = 42
print("\nView test (change original)")
print("  original:", arr)
print("  view    :", y)

y[1] = 99
print("View test (change view)")
print("  original:", arr)
print("  view    :", y)

# Check ownership with .base
print("\nOwnership")
c = arr.copy()
v = arr.view()
print("  copy.base :", c.base)
print("  view.base is arr :", v.base is arr)

# Slices are views, reshape usually returns a view too
s = arr[1:3]
print("  slice is a view :", s.base is arr)
r = arr.reshape(5, 1)
print("  reshape is a view:", r.base is arr)
