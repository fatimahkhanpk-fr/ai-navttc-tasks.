# Week 4 - Task 41: Pandas basics
import pandas as pd

print("Pandas version:", pd.__version__)

# Pandas is used for analyzing, cleaning, exploring and manipulating data.
mydataset = {
    "cars": ["BMW", "Volvo", "Ford"],
    "passings": [3, 7, 2],
}
myvar = pd.DataFrame(mydataset)
print(myvar)

# Common first steps
print("\nShape:", myvar.shape)
print("Columns:", list(myvar.columns))
print("\nSelect a column:\n", myvar["cars"])
print("\nFilter rows (passings > 2):\n", myvar[myvar["passings"] > 2])
print("\nDescribe:\n", myvar.describe())
