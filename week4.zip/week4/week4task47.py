# Week 4 - Task 47: Pandas - data cleaning techniques
import io
import pandas as pd

# Messy data: empty cells, wrong format, wrong data, duplicates
csv = """Duration,Date,Pulse,Calories
60,2020/12/01,110,409.1
60,2020/12/02,117,479.0
60,2020/12/03,103,340.0
45,2020/12/04,109,282.4
45,2020/12/05,117,
60,2020/12/06,102,300.0
60,2020/12/06,102,300.0
450,2020/12/08,104,253.3
30,20201226,109,195.1
60,2020/12/10,,269.0
60,,100,250.7
"""
df = pd.read_csv(io.StringIO(csv))
print("Original data:\n", df)
print("\nMissing values:\n", df.isnull().sum())

# 1. Empty cells: drop rows
print("\n1. dropna():\n", df.dropna())

# 2. Empty cells: fill with a value
filled = df.copy()
filled["Calories"] = filled["Calories"].fillna(130)
print("\n2. fillna on Calories:\n", filled["Calories"].tolist())

# 3. Fill with mean / median / mode
filled = df.copy()
filled["Calories"] = filled["Calories"].fillna(filled["Calories"].mean())
filled["Pulse"] = filled["Pulse"].fillna(filled["Pulse"].median())
print("\n3. Filled with mean/median:\n", filled)

# 4. Wrong format: convert dates
clean = df.copy()
clean["Date"] = pd.to_datetime(clean["Date"], format="mixed", errors="coerce")
print("\n4. Dates converted:\n", clean["Date"])
clean = clean.dropna(subset=["Date"])

# 5. Wrong data: fix values or remove rows
clean.loc[clean["Duration"] > 120, "Duration"] = 45      # replace the outlier
print("\n5. Duration after fixing outlier:\n", clean["Duration"].tolist())

# 6. Duplicates
print("\n6. Duplicated rows:\n", clean.duplicated().tolist())
clean = clean.drop_duplicates()

# 7. Rename columns, change types, reset index
clean = clean.rename(columns={"Pulse": "pulse_bpm"}).reset_index(drop=True)
clean["Duration"] = clean["Duration"].astype(int)
print("\n7. Final cleaned data:\n", clean)
