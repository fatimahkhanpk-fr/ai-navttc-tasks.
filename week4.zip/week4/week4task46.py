# Week 4 - Task 46: Pandas - analyzing data
import io
import pandas as pd

csv = """Duration,Pulse,Maxpulse,Calories
60,110,130,409.1
60,117,145,479.0
60,103,135,340.0
45,109,175,282.4
45,117,148,406.0
60,102,127,300.0
60,110,136,374.0
45,104,134,253.3
30,109,133,195.1
60,98,124,269.0
60,103,147,329.3
60,100,120,250.7
"""
df = pd.read_csv(io.StringIO(csv))

print("head(5):\n", df.head(5))
print("\ntail(3):\n", df.tail(3))

print("\ninfo():")
df.info()

print("\ndescribe():\n", df.describe().round(2))

print("\nColumn dtypes:\n", df.dtypes)
print("\nNull values per column:\n", df.isnull().sum())

print("\nUnique values in Duration:", df["Duration"].unique())
print("Value counts of Duration:\n", df["Duration"].value_counts())

print("\nSorted by Calories (desc):\n", df.sort_values("Calories", ascending=False).head(3))
print("\nAverage calories by Duration:\n", df.groupby("Duration")["Calories"].mean().round(1))
print("\nRows with Calories > 400:\n", df[df["Calories"] > 400])
