# Week 4 - Task 48: Pandas - data correlations
import io
import pandas as pd

csv = """Duration,Pulse,Maxpulse,Calories
60,110,130,409.1
60,117,145,479.0
60,103,135,340.0
45,109,175,282.4
45,117,148,406.0
60,102,127,300.0
60,110,136,374.0
45,104,134,253.3
30,109,133,195.1
60,98,124,269.0
60,103,147,329.3
60,100,120,250.7
"""
df = pd.read_csv(io.StringIO(csv))

# corr() shows the relationship between every pair of numeric columns.
# Value ranges from -1 to 1:
#   1  = perfect positive correlation
#   0  = no relationship
#  -1  = perfect negative correlation
corr = df.corr(numeric_only=True)
print("Correlation matrix:\n", corr.round(3))

print("\nDuration vs Calories:", round(df["Duration"].corr(df["Calories"]), 3))
print("Pulse vs Calories   :", round(df["Pulse"].corr(df["Calories"]), 3))

# Strongest relationship with Calories
print("\nCorrelation with Calories (sorted):")
print(corr["Calories"].drop("Calories").sort_values(ascending=False).round(3))

# Rule of thumb: > 0.6 good, < -0.6 good (inverse), -0.3..0.3 not useful
for col in corr.columns.drop("Calories"):
    r = corr.loc[col, "Calories"]
    if abs(r) >= 0.6:
        verdict = "strong"
    elif abs(r) >= 0.3:
        verdict = "moderate"
    else:
        verdict = "weak"
    print(f"{col:9s} r = {r:6.3f} -> {verdict}")

# Other methods
print("\nSpearman:\n", df.corr(method="spearman").round(2)["Calories"])

# Optional picture of the matrix
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots()
    im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr)), corr.columns, rotation=45)
    ax.set_yticks(range(len(corr)), corr.columns)
    fig.colorbar(im)
    fig.tight_layout()
    fig.savefig("week4task48_correlation.png")
    print("\nSaved week4task48_correlation.png")
except ImportError:
    pass
