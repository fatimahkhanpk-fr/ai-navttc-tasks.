# Week 4 - Task 43: Pandas Series
import pandas as pd
import numpy as np

# A Series is a one-dimensional labelled array
a = [1, 7, 2]
myvar = pd.Series(a)
print(myvar)
print("First value:", myvar[0])

# Custom labels (index)
myvar = pd.Series(a, index=["x", "y", "z"])
print("\n", myvar)
print("Value at label 'y':", myvar["y"])

# From a dictionary
calories = {"day1": 420, "day2": 380, "day3": 390}
s = pd.Series(calories)
print("\nFrom dict:\n", s)
print("Only day1 and day2:\n", pd.Series(calories, index=["day1", "day2"]))

# Attributes and methods
print("\nindex:", list(s.index), "| values:", s.values, "| dtype:", s.dtype)
print("sum:", s.sum(), "| mean:", round(s.mean(), 2), "| max:", s.max())

# Vectorised operations and filtering
print("\ns + 10:\n", s + 10)
print("s > 385:\n", s[s > 385])

# Naming a Series & NaN
s.name = "calories"
print("\nName:", s.name)
print(pd.Series([1, np.nan, 3]).isnull().tolist())
