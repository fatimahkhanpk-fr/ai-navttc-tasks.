# Week 4 - Task 44: Pandas DataFrames
import pandas as pd

data = {
    "calories": [420, 380, 390],
    "duration": [50, 40, 45],
}
df = pd.DataFrame(data)
print(df)

# Locate rows with loc
print("\nRow 0:\n", df.loc[0])
print("\nRows 0 and 1:\n", df.loc[[0, 1]])

# Named indexes
df = pd.DataFrame(data, index=["day1", "day2", "day3"])
print("\n", df)
print("\nloc['day2']:\n", df.loc["day2"])

# Columns, shape, info
print("\nColumns:", list(df.columns), "| shape:", df.shape)
df.info()

# Add / modify / delete columns
df["pace"] = df["calories"] / df["duration"]
print("\nWith new column:\n", df.round(2))
df = df.drop(columns=["pace"])

# Add a row
df.loc["day4"] = [400, 42]
print("\nWith new row:\n", df)

# Selecting
print("\nTwo columns:\n", df[["calories", "duration"]])
print("iloc[1:3]:\n", df.iloc[1:3])

# Build from a list of dictionaries and from a list of lists
print(pd.DataFrame([{"a": 1, "b": 2}, {"a": 3, "b": 4}]))
print(pd.DataFrame([[1, 2], [3, 4]], columns=["x", "y"]))
