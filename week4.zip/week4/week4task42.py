# Week 4 - Task 42: Pandas installation / getting started
# Install (run in a terminal):   pip install pandas
# or with Anaconda:              conda install pandas

import sys

try:
    import pandas as pd
except ImportError:
    sys.exit("Pandas is not installed. Run:  pip install pandas")

print("Pandas is installed. Version:", pd.__version__)

# Create a simple DataFrame to prove it works
mydataset = {"cars": ["BMW", "Volvo", "Ford"], "passings": [3, 7, 2]}
myvar = pd.DataFrame(mydataset)
print(myvar)

# Using the standard alias
import pandas as pd
print("\nUsing the alias pd:", pd.Series([1, 2, 3]).sum())

# Check other tools that are normally used with Pandas
for lib in ["numpy", "matplotlib", "seaborn", "sklearn"]:
    try:
        m = __import__(lib)
        print(f"{lib:12s} installed ({getattr(m, '__version__', '?')})")
    except ImportError:
        print(f"{lib:12s} NOT installed -> pip install {lib}")
