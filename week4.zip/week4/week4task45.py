# Week 4 - Task 45: Pandas - read CSV files
import os
import pandas as pd

# Create a sample CSV so the script runs anywhere (replace with your own file)
csv_path = "data.csv"
rows = """Duration,Pulse,Maxpulse,Calories
60,110,130,409.1
60,117,145,479.0
60,103,135,340.0
45,109,175,282.4
45,117,148,406.0
60,102,127,300.0
60,110,136,374.0
45,104,134,253.3
30,109,133,195.1
60,98,124,269.0
60,103,147,329.3
60,100,120,250.7
"""
with open(csv_path, "w") as f:
    f.write(rows)

# Read the CSV
df = pd.read_csv(csv_path)
print(df)                          # to_string() prints everything; head() / tail() preview

print("\nhead(3):\n", df.head(3))
print("\ntail(3):\n", df.tail(3))
print("\nShape:", df.shape)

# pd.options.display.max_rows controls how many rows are shown
print("max_rows setting:", pd.options.display.max_rows)

# Useful read_csv options
sub = pd.read_csv(csv_path, usecols=["Duration", "Calories"], nrows=4)
print("\nusecols + nrows:\n", sub)

# Save to CSV and JSON
df.to_csv("data_copy.csv", index=False)
df.to_json("data.json")
print("\nSaved data_copy.csv and data.json")

# Clean up the demo files
for p in ["data_copy.csv", "data.json", csv_path]:
    os.remove(p)
