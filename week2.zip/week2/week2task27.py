# Week 2 - Task 27: Exercises on User Defined Exception Handling in Python

# 1. Basic custom exception
class MyError(Exception):
    pass

try:
    raise MyError("Something custom went wrong")
except MyError as e:
    print("1. Caught MyError:", e)

# 2. Custom exceptions with a hierarchy
class BankError(Exception):
    """Base class for bank exceptions"""

class InsufficientFundsError(BankError):
    def __init__(self, balance, amount):
        self.balance = balance
        self.amount = amount
        super().__init__(f"Cannot withdraw {amount}; balance is only {balance}")

class NegativeAmountError(BankError):
    pass

class Account:
    def __init__(self, balance=0):
        self.balance = balance

    def withdraw(self, amount):
        if amount < 0:
            raise NegativeAmountError("Amount must be positive")
        if amount > self.balance:
            raise InsufficientFundsError(self.balance, amount)
        self.balance -= amount
        return self.balance

acc = Account(100)
for amt in [30, -5, 500]:
    try:
        print("2. New balance:", acc.withdraw(amt))
    except InsufficientFundsError as e:
        print("2. InsufficientFundsError:", e, "| short by", e.amount - e.balance)
    except BankError as e:
        print("2. BankError:", e)

# 3. Salary range validation (classic example)
class SalaryNotInRangeError(Exception):
    def __init__(self, salary, low=5000, high=15000):
        self.salary = salary
        super().__init__(f"Salary {salary} is not in range ({low}, {high})")

for salary in [8000, 20000]:
    try:
        if not 5000 < salary < 15000:
            raise SalaryNotInRangeError(salary)
        print("3. Salary accepted:", salary)
    except SalaryNotInRangeError as e:
        print("3.", e)

# 4. Guess-the-number style: exceptions with a hint
class ValueTooSmallError(Exception): pass
class ValueTooLargeError(Exception): pass

target = 10
for guess in [4, 15, 10]:
    try:
        if guess < target:
            raise ValueTooSmallError
        if guess > target:
            raise ValueTooLargeError
        print("4. Correct guess!", guess)
    except ValueTooSmallError:
        print("4. Too small:", guess)
    except ValueTooLargeError:
        print("4. Too large:", guess)

# 5. Re-raising with exception chaining
def load(value):
    try:
        return int(value)
    except ValueError as e:
        raise MyError(f"Could not load '{value}'") from e

try:
    load("abc")
except MyError as e:
    print("5.", e, "| caused by:", repr(e.__cause__))
