# Week 2 - Task 50: Standard Deviation
import math
import numpy as np

# Two groups of speeds: one close to the mean, one widely spread
speed_a = [86, 87, 88, 86, 87, 85, 86]
speed_b = [32, 111, 138, 28, 59, 77, 97]

def std_manual(data, sample=False):
    mean = sum(data) / len(data)
    squared_diffs = [(x - mean) ** 2 for x in data]
    variance = sum(squared_diffs) / (len(data) - 1 if sample else len(data))
    return variance, math.sqrt(variance)

for name, data in [("speed_a", speed_a), ("speed_b", speed_b)]:
    mean = np.mean(data)
    var_np = np.var(data)
    std_np = np.std(data)
    var_m, std_m = std_manual(data)
    print(f"{name}: {data}")
    print(f"  mean                = {mean:.3f}")
    print(f"  variance (numpy)    = {var_np:.3f}   manual = {var_m:.3f}")
    print(f"  std dev  (numpy)    = {std_np:.3f}   manual = {std_m:.3f}")
    print(f"  sample std (ddof=1) = {np.std(data, ddof=1):.3f}")
    print(f"  coefficient of var. = {std_np / mean * 100:.2f}%")
    print(f"  most values lie between {mean - std_np:.1f} and {mean + std_np:.1f}\n")

print("A small standard deviation means values are close to the mean;")
print("a large one means they are spread over a wider range.")
