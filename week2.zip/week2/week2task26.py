# Week 2 - Task 26: Exercises on Exception Handling in Python
import os

# 1. try / except
try:
    print(10 / 0)
except ZeroDivisionError:
    print("1. Cannot divide by zero")

# 2. Multiple except blocks
def convert(value):
    try:
        return int(value)
    except ValueError:
        print(f"2. ValueError: '{value}' is not a number")
    except TypeError:
        print("2. TypeError: wrong type")

convert("abc")
convert(None)

# 3. Catch the exception object
try:
    [1, 2, 3][10]
except IndexError as e:
    print("3. IndexError:", e)

# 4. else and finally
def divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("4. Division by zero")
    else:
        print("4. Result:", result)
    finally:
        print("4. finally always runs")

divide(10, 2)
divide(10, 0)

# 5. Catch several exceptions in one clause
try:
    int("x")
except (ValueError, TypeError) as e:
    print("5. Caught:", type(e).__name__)

# 6. KeyError
try:
    {"a": 1}["b"]
except KeyError as e:
    print("6. KeyError, missing key:", e)

# 7. FileNotFoundError
try:
    with open("does_not_exist.txt") as f:
        f.read()
except FileNotFoundError:
    print("7. File not found")

# 8. raise your own error
def set_age(age):
    if age < 0:
        raise ValueError("Age cannot be negative")
    return age

try:
    set_age(-5)
except ValueError as e:
    print("8. ValueError:", e)

# 9. assert
try:
    assert 2 + 2 == 5, "Math is broken"
except AssertionError as e:
    print("9. AssertionError:", e)

# 10. Reading user input safely (uses a fixed list so the script runs without typing)
for text in ["42", "forty", "7"]:
    try:
        print("10. Parsed:", int(text))
    except ValueError:
        print("10. Invalid input:", text)

# 11. File handling with exception handling
path = "week2_demo.txt"
try:
    with open(path, "w") as f:
        f.write("line 1\nline 2\n")
    with open(path) as f:
        print("11. File content:", f.read().split())
finally:
    if os.path.exists(path):
        os.remove(path)
