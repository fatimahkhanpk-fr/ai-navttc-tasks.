# Week 2 - Task 20: Exercises on user defined functions in Python

# 1. Simple function with no arguments
def greet():
    print("Hello from a function!")

greet()

# 2. Parameters and return value
def add(a, b):
    return a + b

print("add(3, 4) =", add(3, 4))

# 3. Default arguments
def power(base, exp=2):
    return base ** exp

print("power(5) =", power(5), "| power(2, 10) =", power(2, 10))

# 4. Keyword arguments
def describe(name, age, city="Karachi"):
    return f"{name}, {age} years old, from {city}"

print(describe(age=21, name="Ali"))

# 5. *args and **kwargs
def total(*args):
    return sum(args)

def show(**kwargs):
    for k, v in kwargs.items():
        print(f"  {k} = {v}")

print("total(1, 2, 3, 4) =", total(1, 2, 3, 4))
show(a=1, b=2)

# 6. Returning multiple values
def min_max(numbers):
    return min(numbers), max(numbers)

lo, hi = min_max([4, 9, 1, 7])
print("min, max =", lo, hi)

# 7. Factorial (recursion)
def factorial(n):
    return 1 if n <= 1 else n * factorial(n - 1)

print("factorial(6) =", factorial(6))

# 8. Fibonacci
def fibonacci(n):
    seq, a, b = [], 0, 1
    for _ in range(n):
        seq.append(a)
        a, b = b, a + b
    return seq

print("fibonacci(10) =", fibonacci(10))

# 9. Prime check
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

print("primes below 30:", [n for n in range(30) if is_prime(n)])

# 10. Variable scope
x = "global"
def scope_demo():
    x = "local"
    print("inside:", x)

scope_demo()
print("outside:", x)

counter = 0
def increment():
    global counter
    counter += 1

increment(); increment()
print("counter =", counter)

# 11. Lambda, map, filter
square = lambda n: n * n
print(square(7))
print(list(map(lambda n: n * 2, [1, 2, 3])))
print(list(filter(lambda n: n % 2 == 0, range(10))))

# 12. Nested (inner) function
def outer(msg):
    def inner():
        return msg.upper()
    return inner()

print(outer("nested"))

# 13. Passing a function as an argument
def apply(func, value):
    return func(value)

print(apply(abs, -15))
