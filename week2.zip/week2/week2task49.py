# Week 2 - Task 49: Mean, Median and Mode
import statistics
from collections import Counter

import numpy as np

# Speed of 13 cars
speed = [99, 86, 87, 88, 111, 86, 103, 87, 94, 78, 77, 85, 86]
print("Data:", speed)

# Mean - the average value
mean_np = np.mean(speed)
mean_manual = sum(speed) / len(speed)
print("\nMean   (numpy)  :", round(mean_np, 4))
print("Mean   (manual) :", round(mean_manual, 4))

# Median - the middle value after sorting
median_np = np.median(speed)
ordered = sorted(speed)
n = len(ordered)
mid = n // 2
median_manual = ordered[mid] if n % 2 else (ordered[mid - 1] + ordered[mid]) / 2
print("\nSorted:", ordered)
print("Median (numpy)  :", median_np)
print("Median (manual) :", median_manual)

# Even-length example: the median is the average of the two middle values
print("Median of [77, 78, 85, 86, 86, 86, 87, 87, 94, 98, 99, 103]:",
      np.median([77, 78, 85, 86, 86, 86, 87, 87, 94, 98, 99, 103]))

# Mode - the most common value
mode_stat = statistics.mode(speed)
counts = Counter(speed)
mode_manual, freq = counts.most_common(1)[0]
print("\nMode (statistics):", mode_stat)
print(f"Mode (manual)    : {mode_manual} (appears {freq} times)")

# Multi-modal data
print("Modes of [1, 1, 2, 2, 3]:", statistics.multimode([1, 1, 2, 2, 3]))
