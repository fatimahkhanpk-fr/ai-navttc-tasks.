# Week 5 - Task 52: Perform Logistic Regression
# Part 1: binary classification   Part 2: multiclass digit recognition (MNIST-style)
import numpy as np
import matplotlib
matplotlib.use("Agg")          # remove this line to open plot windows
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer, load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

# ---------------------------------------------------------------
# Part 1: Binary logistic regression (breast cancer: malignant vs benign)
# ---------------------------------------------------------------
data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.25, random_state=0, stratify=data.target)

binary = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
binary.fit(X_train, y_train)
pred = binary.predict(X_test)

print("=== Binary logistic regression ===")
print("Accuracy:", round(accuracy_score(y_test, pred), 4))
print("Confusion matrix:\n", confusion_matrix(y_test, pred))
print(classification_report(y_test, pred, target_names=data.target_names))
print("Probabilities for first 3 test samples:\n", binary.predict_proba(X_test[:3]).round(3))

# ---------------------------------------------------------------
# Part 2: Multiclass logistic regression (8x8 handwritten digits, 10 classes)
# ---------------------------------------------------------------
digits = load_digits()
X_train, X_test, y_train, y_test = train_test_split(
    digits.data, digits.target, test_size=0.25, random_state=0)

multi = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
multi.fit(X_train, y_train)
pred = multi.predict(X_test)

print("\n=== Multiclass logistic regression (digits) ===")
print("Accuracy:", round(accuracy_score(y_test, pred), 4))
cm = confusion_matrix(y_test, pred)
print("Confusion matrix:\n", cm)

# Plot a few predictions
fig, axes = plt.subplots(2, 5, figsize=(8, 4))
for ax, img, true, p in zip(axes.ravel(), X_test, y_test, pred):
    ax.imshow(img.reshape(8, 8), cmap="gray_r")
    ax.set_title(f"pred {p} / true {true}", fontsize=8)
    ax.axis("off")
fig.tight_layout()
fig.savefig("week5task52_digits.png")

plt.figure(figsize=(5, 5))
plt.imshow(cm, cmap="Blues")
plt.title("Confusion matrix"); plt.xlabel("Predicted"); plt.ylabel("True"); plt.colorbar()
plt.tight_layout(); plt.savefig("week5task52_confusion.png")
print("\nSaved plots: week5task52_digits.png, week5task52_confusion.png")
