# Week 5 - Task 51: Implement Linear Regression (scikit-learn)
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # remove this line to open plot windows
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------
# Part 1: Simple linear regression (one feature)  y = 2.5x + 10 + noise
# ---------------------------------------------------------------
rng = np.random.default_rng(42)
hours = rng.uniform(1, 10, 100)
score = 10 + 2.5 * hours + rng.normal(0, 2, 100)
X = hours.reshape(-1, 1)
y = score

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
model = LinearRegression().fit(X_train, y_train)
pred = model.predict(X_test)

print("=== Simple linear regression ===")
print(f"Intercept : {model.intercept_:.3f}  (true value 10)")
print(f"Slope     : {model.coef_[0]:.3f}  (true value 2.5)")
print(f"MAE       : {mean_absolute_error(y_test, pred):.3f}")
print(f"MSE       : {mean_squared_error(y_test, pred):.3f}")
print(f"RMSE      : {np.sqrt(mean_squared_error(y_test, pred)):.3f}")
print(f"R^2       : {r2_score(y_test, pred):.3f}")
print("Prediction for 7.5 hours:", round(float(model.predict([[7.5]])[0]), 2))

plt.figure(figsize=(6, 4))
plt.scatter(X_test, y_test, label="actual")
line_x = np.linspace(1, 10, 50).reshape(-1, 1)
plt.plot(line_x, model.predict(line_x), color="red", label="regression line")
plt.xlabel("Hours studied"); plt.ylabel("Score"); plt.legend()
plt.title("Simple Linear Regression")
plt.tight_layout(); plt.savefig("week5task51_simple.png")

# ---------------------------------------------------------------
# Part 2: Multiple linear regression on the built-in diabetes dataset
# ---------------------------------------------------------------
data = load_diabetes(as_frame=True)
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

multi = LinearRegression().fit(X_train, y_train)
pred = multi.predict(X_test)

print("\n=== Multiple linear regression (diabetes dataset) ===")
print("Intercept:", round(multi.intercept_, 2))
print(pd.DataFrame({"feature": X.columns, "coefficient": multi.coef_.round(2)}).to_string(index=False))
print(f"RMSE: {np.sqrt(mean_squared_error(y_test, pred)):.2f} | R^2: {r2_score(y_test, pred):.3f}")

plt.figure(figsize=(5, 5))
plt.scatter(y_test, pred, alpha=0.7)
plt.plot([y.min(), y.max()], [y.min(), y.max()], "r--")
plt.xlabel("Actual"); plt.ylabel("Predicted"); plt.title("Actual vs Predicted")
plt.tight_layout(); plt.savefig("week5task51_multiple.png")
print("\nSaved plots: week5task51_simple.png, week5task51_multiple.png")
