# Week 1 - Task 22: Exercises on the Tuple data type

t = (10, 20, 30, 40, 50)
print("Tuple:", t, "| type:", type(t))

# Indexing and slicing
print("t[0] =", t[0], "| t[-1] =", t[-1], "| t[1:4] =", t[1:4])

# Tuples are immutable
try:
    t[0] = 99
except TypeError as e:
    print("Error:", e)

# Single-element tuple needs a trailing comma
single = (5,)
not_tuple = (5)
print(type(single), type(not_tuple))

# Packing and unpacking
person = ("Ali", 22, "Karachi")
name, age, city = person
print(name, age, city)
first, *middle, last = (1, 2, 3, 4, 5)
print(first, middle, last)

# Methods
nums = (1, 2, 2, 3, 2)
print("count of 2:", nums.count(2), "| index of 3:", nums.index(3))

# Concatenation / repetition / membership
print((1, 2) + (3, 4), (0,) * 3, 2 in nums)

# Convert between list and tuple (to "modify" a tuple)
lst = list(t)
lst.append(60)
t = tuple(lst)
print("New tuple:", t)

# Nested tuple and swapping values
nested = ((1, 2), (3, 4))
print(nested[1][0])
a, b = 1, 2
a, b = b, a
print(a, b)
