# Week 1 - Task 18: Exercises on the continue statement

# 1. Skip one value
print("1. Numbers 1-10 without 5")
for i in range(1, 11):
    if i == 5:
        continue
    print(i, end=" ")
print()

# 2. Print only odd numbers
print("\n2. Odd numbers")
for i in range(1, 16):
    if i % 2 == 0:
        continue
    print(i, end=" ")
print()

# 3. Skip vowels in a string
print("\n3. 'Programming' without vowels")
for ch in "Programming":
    if ch.lower() in "aeiou":
        continue
    print(ch, end="")
print()

# 4. continue in a while loop (increment BEFORE continue to avoid infinite loop)
print("\n4. While loop, skipping multiples of 3")
i = 0
while i < 10:
    i += 1
    if i % 3 == 0:
        continue
    print(i, end=" ")
print()

# 5. Sum of positive numbers only
nums = [4, -2, 7, -9, 10, 0, -1]
total = 0
for n in nums:
    if n <= 0:
        continue
    total += n
print("\n5. Sum of positives in", nums, "=", total)
