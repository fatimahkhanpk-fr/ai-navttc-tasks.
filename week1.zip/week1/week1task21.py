# Week 1 - Task 21: Exercises on the List data type

fruits = ["apple", "banana", "cherry"]
print("Original:", fruits)

# Indexing and slicing
print("First:", fruits[0], "| Last:", fruits[-1])
nums = [10, 20, 30, 40, 50, 60]
print("nums[1:4] =", nums[1:4], "| nums[::-1] =", nums[::-1])

# Add elements
fruits.append("orange")
fruits.insert(1, "mango")
fruits.extend(["kiwi", "grape"])
print("After adding:", fruits)

# Remove elements
fruits.remove("banana")
popped = fruits.pop()
del fruits[0]
print("After removing:", fruits, "| popped:", popped)

# Change an element
fruits[0] = "papaya"
print("After change:", fruits)

# Useful methods
data = [5, 3, 8, 1, 9, 3]
print("\nlen:", len(data), "max:", max(data), "min:", min(data), "sum:", sum(data))
print("count of 3:", data.count(3), "| index of 8:", data.index(8))
data.sort()
print("sorted:", data)
data.reverse()
print("reversed:", data)

# Copying (a = b does NOT copy)
a = [1, 2, 3]
b = a.copy()
b.append(4)
print("\na:", a, "b:", b)

# Membership + concatenation + repetition
print(3 in a, [1, 2] + [3], [0] * 4)

# List comprehension & nested list
print([x * x for x in range(1, 6)])
matrix = [[1, 2], [3, 4]]
print("matrix[1][0] =", matrix[1][0])
