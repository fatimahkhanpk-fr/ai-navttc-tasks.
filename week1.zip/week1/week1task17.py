# Week 1 - Task 17: Exercises on the break statement

# 1. Stop a for loop when a value is found
for fruit in ["apple", "banana", "cherry", "date"]:
    if fruit == "cherry":
        print("1. Found cherry, stopping")
        break
    print("Checking", fruit)

# 2. Break in a while loop
n = 0
while True:
    n += 1
    if n * n > 200:
        print("2. First n with n^2 > 200 is", n)
        break

# 3. Prime number check
number = 29
is_prime = True
for i in range(2, int(number ** 0.5) + 1):
    if number % i == 0:
        is_prime = False
        break
print(f"3. {number} is prime:", is_prime)

# 4. break only exits the innermost loop
print("4. Nested loops")
for i in range(1, 4):
    for j in range(1, 4):
        if j == 3:
            break
        print(f"i={i}, j={j}")

# 5. for-else: else runs only if break did NOT happen
for n in range(2, 10):
    for x in range(2, n):
        if n % x == 0:
            break
    else:
        print("5. prime:", n)
