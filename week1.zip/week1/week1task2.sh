#!/bin/bash
# Week 1 - Task 2: Linux Commands practice (Debian/Ubuntu)
# Run:  bash week1task2.sh
# Everything happens inside a throw-away folder (~/linux_practice), so it is safe.

section() { echo; echo "=================== $1 ==================="; }

section "pwd, mkdir, cd, ls"
pwd
mkdir -p ~/linux_practice
cd ~/linux_practice
pwd
mkdir -p dir1 dir2 dir_to_remove
ls
ls -l
ls -la

section "touch, redirection (>, >>), cat"
touch empty.txt
echo "Hello Linux"            >  hello.txt     # > overwrites
echo "This is line 2"         >> hello.txt     # >> appends
printf "line %s\n" 1 2 3 4 5 6 7 8 9 10 11 12 > numbers.txt
cat hello.txt

section "file, more, less, head"
file hello.txt
file /bin/ls
head -n 5 numbers.txt
echo "(more/less are interactive pagers; run them manually:  more numbers.txt   less numbers.txt)"
# more numbers.txt
# less numbers.txt

section "cp, mv, rm, rmdir"
cp hello.txt dir1/hello_copy.txt
mv dir1/hello_copy.txt dir2/hello_moved.txt
ls dir1 dir2
rm dir2/hello_moved.txt
rmdir dir_to_remove          # works only on empty directories
rm -r dir1 dir2              # -r removes non-empty directories
ls

section "man (manual pages)"
man ls 2>/dev/null | head -n 5 || echo "man pages not installed"

section "alias"
alias ll='ls -la'
alias
# make it permanent:  echo "alias ll='ls -la'" >> ~/.bashrc

section "nano (text editor)"
echo "Open an editor manually with:  nano notes.txt   (Ctrl+O save, Ctrl+X exit)"

section "bash / sh and chmod"
cat > myscript.sh << 'INNER'
#!/bin/bash
echo "Running myscript.sh"
INNER
ls -l myscript.sh
chmod +x myscript.sh
ls -l myscript.sh
./myscript.sh
bash myscript.sh
sh myscript.sh
chmod 644 hello.txt
ls -l hello.txt

section "ps and kill"
ps
sleep 300 &                  # start a background process
PID=$!
echo "Started sleep with PID $PID"
ps -p $PID
kill $PID
sleep 0.5
ps -p $PID || echo "Process $PID has been killed"

section "sudo, dpkg, package update/upgrade (Debian/Ubuntu)"
echo "These need root, so they are shown but not executed:"
echo "  sudo apt update"
echo "  sudo apt upgrade -y"
echo "  dpkg -l | head          # list installed packages"
echo "  dpkg -s bash            # status of one package"
command -v dpkg >/dev/null && dpkg -l | head -n 5

section "Environment variables"
echo "HOME  = $HOME"
echo "USER  = ${USER:-unknown}"
export MY_VAR="Hello AI"
echo "MY_VAR = $MY_VAR"
printenv | head -n 3

section "shutdown / restart (NOT executed)"
echo "  sudo shutdown now"
echo "  sudo shutdown -r now      # restart"
echo "  sudo reboot"

section "cleanup"
cd ~
rm -r ~/linux_practice
echo "Done."
