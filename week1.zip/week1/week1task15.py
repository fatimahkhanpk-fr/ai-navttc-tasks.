# Week 1 - Task 15: Exercises on for loops

# 1. Loop over a list
print("1. Fruits")
for fruit in ["apple", "banana", "cherry"]:
    print(fruit)

# 2. Loop over a string
print("\n2. Letters of 'Python'")
for ch in "Python":
    print(ch, end=" ")
print()

# 3. range(): start, stop, step
print("\n3. range(1, 11)")
for i in range(1, 11):
    print(i, end=" ")
print()
print("Even numbers 2..20:", end=" ")
for i in range(2, 21, 2):
    print(i, end=" ")
print()

# 4. Sum of first 100 numbers
total = 0
for i in range(1, 101):
    total += i
print("\n4. Sum of 1..100 =", total)

# 5. Multiplication table
n = 5
print(f"\n5. Table of {n}")
for i in range(1, 11):
    print(f"{n} x {i} = {n * i}")

# 6. Factorial
n = 6
fact = 1
for i in range(2, n + 1):
    fact *= i
print(f"\n6. {n}! = {fact}")

# 7. Loop over a dictionary
print("\n7. Dictionary")
marks = {"Ali": 80, "Sara": 92, "Ahmed": 75}
for name, score in marks.items():
    print(name, "->", score)

# 8. for-else
print("\n8. for-else")
for i in range(3):
    print("iteration", i)
else:
    print("loop finished without break")

# 9. Star pattern (nested loops)
print("\n9. Pattern")
for i in range(1, 6):
    print("*" * i)
