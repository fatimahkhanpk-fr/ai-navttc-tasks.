# Week 1 - Task 24: Exercises on the Set data type

s = {1, 2, 3, 3, 2, 1}
print("Set (duplicates removed):", s, "| type:", type(s))
empty = set()          # {} would create a dictionary
print("Empty set:", empty, type(empty))

# From a list: remove duplicates
print(set([1, 1, 2, 3, 3, 4]))

# Add / update
s.add(4)
s.update([5, 6, 7])
print("After add/update:", s)

# Remove
s.remove(7)          # KeyError if missing
s.discard(100)       # no error if missing
popped = s.pop()     # removes an arbitrary element
print("After removal:", s, "| popped:", popped)

# Set operations
a = {1, 2, 3, 4, 5}
b = {4, 5, 6, 7}
print("\nUnion:", a | b, a.union(b))
print("Intersection:", a & b, a.intersection(b))
print("Difference a-b:", a - b, a.difference(b))
print("Symmetric difference:", a ^ b, a.symmetric_difference(b))

# Subset / superset / disjoint
print({1, 2} <= a, a >= {1, 2}, a.isdisjoint({10, 11}))

# Membership
print(3 in a, 10 in a)

# Set comprehension
print({x ** 2 for x in range(1, 6)})

# frozenset (immutable set)
fs = frozenset([1, 2, 3])
print(fs)
