# Week 1 - Task 19: Exercises on various looping techniques

# 1. enumerate(): index + value
print("1. enumerate")
for idx, color in enumerate(["red", "green", "blue"], start=1):
    print(idx, color)

# 2. zip(): loop over two sequences together
print("\n2. zip")
names = ["Ali", "Sara", "Ahmed"]
ages = [21, 23, 22]
for n, a in zip(names, ages):
    print(f"{n} is {a} years old")

# 3. items(), keys(), values()
print("\n3. dictionary looping")
d = {"a": 1, "b": 2, "c": 3}
for k, v in d.items():
    print(k, v)
print("keys:", [k for k in d.keys()], "values:", [v for v in d.values()])

# 4. reversed() and sorted()
print("\n4. reversed / sorted")
for x in reversed([1, 2, 3, 4]):
    print(x, end=" ")
print()
for x in sorted([5, 2, 9, 1], reverse=True):
    print(x, end=" ")
print()

# 5. Looping over a set (unique values)
print("\n5. sorted(set(...))")
for x in sorted(set([3, 1, 3, 2, 1])):
    print(x, end=" ")
print()

# 6. List comprehension
print("\n6. list comprehension")
squares = [x ** 2 for x in range(1, 8)]
print(squares)
print([x for x in range(20) if x % 3 == 0])

# 7. Nested loops with a matrix
print("\n7. matrix")
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
for row in matrix:
    for val in row:
        print(val, end=" ")
    print()

# 8. Iterator protocol
print("\n8. iter / next")
it = iter(["x", "y", "z"])
print(next(it), next(it), next(it))

# 9. Looping in steps and in reverse with range()
print("\n9. range tricks")
print(list(range(10, 0, -2)))
