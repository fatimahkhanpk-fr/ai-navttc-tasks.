# Week 1 - Task 23: Exercises on the String data type

s = "Hello, Python World"
print("String:", s, "| length:", len(s))

# Indexing and slicing
print(s[0], s[-1], s[7:13], s[::-1])

# Case methods
print(s.upper(), s.lower(), s.title(), s.swapcase(), "hello world".capitalize())

# Search and replace
print(s.find("Python"), s.count("o"), s.replace("World", "AI"))
print(s.startswith("Hello"), s.endswith("d"))

# Strip, split, join
raw = "   padded text   "
print(f"[{raw.strip()}]")
words = s.split()
print(words, "-".join(words))
print("a,b,c".split(","))

# Checks
print("abc".isalpha(), "123".isdigit(), "abc123".isalnum(), "   ".isspace())

# Formatting
name, score = "Sara", 92.456
print("Name: {} Score: {:.1f}".format(name, score))
print(f"Name: {name} Score: {score:.2f}")
print("Name: %s Score: %.0f" % (name, score))

# Strings are immutable
try:
    s[0] = "J"
except TypeError as e:
    print("Error:", e)

# Escape characters, multi-line strings
print("Tab\there, newline\\n, quote \" and '")
print("""Multi
line""")

# Palindrome check
word = "madam"
print(word, "is palindrome:", word == word[::-1])

# Count vowels
print("Vowels in s:", sum(1 for c in s.lower() if c in "aeiou"))
