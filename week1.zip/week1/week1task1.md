# Week 1 - Task 1: Installation

Install Anaconda3, PyTorch, TensorFlow 2.0, VSCode and PyCharm.

## 1. Anaconda3
1. Download the installer from https://www.anaconda.com/download (choose your OS, 64-bit).
2. Run it, choose "Just Me", keep the default path.
3. Verify (Anaconda Prompt / terminal):
   ```
   conda --version
   python --version
   ```
4. Create a working environment (recommended):
   ```
   conda create -n aiml python=3.10 -y
   conda activate aiml
   conda install numpy pandas matplotlib seaborn scikit-learn jupyter -y
   ```

## 2. PyTorch (inside the `aiml` environment)
CPU only:
```
pip install torch torchvision torchaudio
```
For a GPU build, pick the exact command at https://pytorch.org/get-started/locally/

Verify:
```
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
```

## 3. TensorFlow 2.x
```
pip install tensorflow
```
Verify:
```
python -c "import tensorflow as tf; print(tf.__version__)"
```

## 4. VSCode
1. Download from https://code.visualstudio.com/ and install.
2. Install the extensions: "Python" and "Jupyter" (Microsoft).
3. Press Ctrl+Shift+P -> "Python: Select Interpreter" -> choose the `aiml` conda environment.

## 5. PyCharm
1. Download PyCharm Community from https://www.jetbrains.com/pycharm/download/ and install.
2. New Project -> "Previously configured interpreter" -> Add Interpreter -> Conda Environment -> select `aiml`.

## Verification script
Save as `check_install.py` and run `python check_install.py`:
```python
import sys
print("Python:", sys.version)
for name in ["numpy", "pandas", "matplotlib", "seaborn", "sklearn", "torch", "tensorflow"]:
    try:
        module = __import__(name)
        print(f"{name:12s} OK  {getattr(module, '__version__', '')}")
    except ImportError:
        print(f"{name:12s} NOT INSTALLED")
```
