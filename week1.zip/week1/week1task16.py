# Week 1 - Task 16: Exercises on while loops

# 1. Count from 1 to 5
print("1. Counting")
count = 1
while count <= 5:
    print(count)
    count += 1

# 2. Sum of digits of a number
n = 98765
total = 0
while n > 0:
    total += n % 10
    n //= 10
print("\n2. Sum of digits of 98765 =", total)

# 3. Reverse a number
n = 12345
rev = 0
while n > 0:
    rev = rev * 10 + n % 10
    n //= 10
print("3. Reverse of 12345 =", rev)

# 4. Fibonacci numbers below 100
a, b = 0, 1
print("\n4. Fibonacci:", end=" ")
while a < 100:
    print(a, end=" ")
    a, b = b, a + b
print()

# 5. Countdown
print("\n5. Countdown")
n = 5
while n > 0:
    print(n)
    n -= 1
print("Lift off!")

# 6. Collatz sequence
n = 27
steps = 0
while n != 1:
    n = n // 2 if n % 2 == 0 else 3 * n + 1
    steps += 1
print("\n6. Collatz steps for 27:", steps)

# 7. while-else
i = 0
while i < 3:
    print("i =", i)
    i += 1
else:
    print("7. while loop ended normally")
