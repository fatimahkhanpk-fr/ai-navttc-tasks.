# Week 1 - Task 25: Exercises on the Dictionary data type

student = {"name": "Ali", "age": 21, "course": "AI"}
print("Dictionary:", student, "| type:", type(student))

# Access
print(student["name"], student.get("age"), student.get("grade", "N/A"))

# Add / update
student["grade"] = "A"
student["age"] = 22
student.update({"city": "Karachi", "age": 23})
print("After add/update:", student)

# Remove
student.pop("city")
del student["grade"]
last = student.popitem()
print("After removal:", student, "| popitem:", last)

# Keys, values, items
d = {"a": 1, "b": 2, "c": 3}
print(list(d.keys()), list(d.values()), list(d.items()))
for k, v in d.items():
    print(k, "->", v)

# Membership (checks keys)
print("a" in d, "z" in d)

# setdefault and fromkeys
d.setdefault("d", 4)
print(d, dict.fromkeys(["x", "y"], 0))

# Dictionary comprehension
print({x: x ** 2 for x in range(1, 6)})

# Nested dictionary
school = {
    "s1": {"name": "Ali", "marks": 80},
    "s2": {"name": "Sara", "marks": 92},
}
print(school["s2"]["name"], school["s2"]["marks"])

# Count characters in a word
word = "banana"
counts = {}
for ch in word:
    counts[ch] = counts.get(ch, 0) + 1
print(counts)

# Sort by value
print(sorted(d.items(), key=lambda kv: kv[1], reverse=True))

# Merge dictionaries
print({**{"a": 1}, **{"b": 2}})
